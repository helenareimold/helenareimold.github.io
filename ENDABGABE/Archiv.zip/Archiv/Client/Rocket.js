var Endabgabe_EIA2;
(function (Endabgabe_EIA2) {
    class Rocket {
    }
    Endabgabe_EIA2.Rocket = Rocket;
})(Endabgabe_EIA2 || (Endabgabe_EIA2 = {}));
//# sourceMappingURL=Rocket.js.map