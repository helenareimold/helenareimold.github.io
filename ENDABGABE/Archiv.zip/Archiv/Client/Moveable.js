var Endabgabe_EIA2;
(function (Endabgabe_EIA2) {
    class Moveable {
    }
    Endabgabe_EIA2.Moveable = Moveable;
})(Endabgabe_EIA2 || (Endabgabe_EIA2 = {}));
//# sourceMappingURL=Moveable.js.map