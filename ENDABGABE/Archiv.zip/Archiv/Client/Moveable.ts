namespace Endabgabe_EIA2 {

    export abstract class Moveable {
        position: Vector;

        abstract draw(): void;



    }











}