namespace Endabgabe_EIA2 {

    export class Rocket{



        
    }









    
}